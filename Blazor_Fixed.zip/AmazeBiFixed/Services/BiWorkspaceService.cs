using System.Globalization;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using System.Xml.Serialization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Components.Forms;
using MyBlazorApp.Models;

namespace MyBlazorApp.Services;

public sealed class BiWorkspaceService
{
    private const long MaxUploadSize = 50 * 1024 * 1024;
    private const int MaxStoredRowsPerTable = 5000;

    private readonly string _rootPath;
    private readonly string _dataSourcesPath;
    private readonly string _dashboardsPath;
    private readonly string _combinationsPath;
    private readonly string _extractsPath;
    private readonly JsonSerializerOptions _jsonOptions = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true
    };

    public BiWorkspaceService(IWebHostEnvironment environment)
    {
        _rootPath = Path.Combine(environment.ContentRootPath, "App_Data", "AmazeBi");
        _dataSourcesPath = Path.Combine(_rootPath, "DataSources");
        _dashboardsPath = Path.Combine(_rootPath, "Dashboards");
        _combinationsPath = Path.Combine(_rootPath, "Combinations");
        _extractsPath = Path.Combine(_rootPath, "Extracts");

        EnsureStorage();
        try
        {
            SeedDemoWorkspace();
        }
        catch
        {
            // Seed failure is non-fatal — the workspace can still be used
        }
    }

    public async Task<IReadOnlyList<DataSourceModel>> GetDataSourcesAsync()
    {
        var sources = new List<DataSourceModel>();

        foreach (var file in Directory.EnumerateFiles(_dataSourcesPath, "*.json"))
        {
            await using var stream = File.OpenRead(file);
            var source = await JsonSerializer.DeserializeAsync<DataSourceModel>(stream, _jsonOptions);
            if (source is not null)
            {
                sources.Add(source);
            }
        }

        return sources
            .OrderByDescending(source => source.UpdatedAt)
            .ToList();
    }

    public async Task<DataSourceModel?> GetDataSourceAsync(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
        {
            return null;
        }

        var path = DataSourcePath(id);
        if (!File.Exists(path))
        {
            return null;
        }

        await using var stream = File.OpenRead(path);
        return await JsonSerializer.DeserializeAsync<DataSourceModel>(stream, _jsonOptions);
    }

    public async Task SaveDataSourceAsync(DataSourceModel source)
    {
        if (string.IsNullOrWhiteSpace(source.Id))
        {
            source.Id = Guid.NewGuid().ToString("N");
        }

        if (source.CreatedAt == default)
        {
            source.CreatedAt = DateTime.UtcNow;
        }

        source.UpdatedAt = DateTime.UtcNow;
        source.ExtractFileName = string.IsNullOrWhiteSpace(source.ExtractFileName)
            ? $"{Slugify(source.Name)}-{source.Id[..8]}.jsonl"
            : source.ExtractFileName;

        await using (var stream = File.Create(DataSourcePath(source.Id)))
        {
            await JsonSerializer.SerializeAsync(stream, source, _jsonOptions);
        }

        await WriteExtractAsync(source);
    }

    public async Task PublishDataSourceAsync(string id)
    {
        var source = await GetDataSourceAsync(id);
        if (source is null)
        {
            return;
        }

        source.IsPublished = true;
        await SaveDataSourceAsync(source);
    }

    public async Task RefreshDataSourceAsync(string id, string message = "Manual extract refresh")
    {
        var source = await GetDataSourceAsync(id);
        if (source is null)
        {
            return;
        }

        source.LastRefreshedAt = DateTimeOffset.UtcNow;
        source.RefreshHistory.Insert(0, new RefreshEventModel
        {
            RefreshedAt = source.LastRefreshedAt.Value,
            Status = "Completed",
            Message = message
        });

        source.RefreshHistory = source.RefreshHistory.Take(25).ToList();
        await SaveDataSourceAsync(source);
    }

    public async Task<TableModel> CreateTableFromBrowserFileAsync(IBrowserFile file)
    {
        var extension = Path.GetExtension(file.Name).ToLowerInvariant();
        return extension switch
        {
            ".xlsx" => await CreateTableFromXlsxAsync(file),
            ".xls" => throw new NotSupportedException("Legacy .xls files are not supported yet. Save the workbook as .xlsx and import it again."),
            _ => await CreateTableFromDelimitedFileAsync(file)
        };
    }

    public TableModel CreateTableFromText(string tableName, string columnText, string rowText)
    {
        var headers = SplitColumnText(columnText);
        var rows = rowText
            .Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .ToList();

        if (headers.Count == 0 && rows.Count > 0)
        {
            var delimiter = DetectDelimiter(rows[0]);
            headers = ParseDelimitedLine(rows[0], delimiter);
            rows.RemoveAt(0);
        }

        if (headers.Count == 0)
        {
            headers.Add("Column1");
        }

        var table = new TableModel
        {
            Name = string.IsNullOrWhiteSpace(tableName) ? "Custom table" : tableName.Trim(),
            SourceType = "Manual table",
            Delimiter = ",",
            Columns = headers.Select(header => new ColumnModel { Name = header }).ToList()
        };

        foreach (var row in rows)
        {
            var values = ParseDelimitedLine(row, DetectDelimiter(row));
            var mappedRow = MapValues(headers, values);
            table.PreviewRows.Add(mappedRow);
            table.RowCount++;
        }

        ApplyInferredColumnTypes(table);
        return table;
    }

    public async Task<IReadOnlyList<DashboardDefinition>> GetDashboardsAsync()
    {
        var dashboards = new List<DashboardDefinition>();

        foreach (var file in Directory.EnumerateFiles(_dashboardsPath, "*.xml"))
        {
            var dashboard = DeserializeXml<DashboardDefinition>(file);
            if (dashboard is not null)
            {
                dashboards.Add(dashboard);
            }
        }

        return await Task.FromResult(dashboards.OrderByDescending(dashboard => dashboard.UpdatedAt).ToList());
    }

    public async Task<DashboardDefinition?> GetDashboardAsync(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
        {
            return null;
        }

        var path = DashboardPath(id);
        return await Task.FromResult(File.Exists(path) ? DeserializeXml<DashboardDefinition>(path) : null);
    }

    public async Task SaveDashboardAsync(DashboardDefinition dashboard)
    {
        if (string.IsNullOrWhiteSpace(dashboard.Id))
        {
            dashboard.Id = Guid.NewGuid().ToString("N");
        }

        if (dashboard.CreatedAt == default)
        {
            dashboard.CreatedAt = DateTime.UtcNow;
        }

        dashboard.UpdatedAt = DateTime.UtcNow;
        SerializeXml(DashboardPath(dashboard.Id), dashboard);
        await Task.CompletedTask;
    }

    public async Task<IReadOnlyList<CombinedDashboardDefinition>> GetCombinationsAsync()
    {
        var combinations = new List<CombinedDashboardDefinition>();

        foreach (var file in Directory.EnumerateFiles(_combinationsPath, "*.xml"))
        {
            var combination = DeserializeXml<CombinedDashboardDefinition>(file);
            if (combination is not null)
            {
                combinations.Add(combination);
            }
        }

        return await Task.FromResult(combinations.OrderByDescending(combination => combination.UpdatedAt).ToList());
    }

    public async Task SaveCombinationAsync(CombinedDashboardDefinition combination)
    {
        if (string.IsNullOrWhiteSpace(combination.Id))
        {
            combination.Id = Guid.NewGuid().ToString("N");
        }

        if (combination.CreatedAt == default)
        {
            combination.CreatedAt = DateTime.UtcNow;
        }

        combination.UpdatedAt = DateTime.UtcNow;
        SerializeXml(CombinationPath(combination.Id), combination);
        await Task.CompletedTask;
    }

    public string GetExtractPath(DataSourceModel source) => Path.Combine(_extractsPath, source.ExtractFileName);

    private async Task<TableModel> CreateTableFromDelimitedFileAsync(IBrowserFile file)
    {
        await using var stream = file.OpenReadStream(MaxUploadSize);
        using var reader = new StreamReader(stream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true);

        var headerLine = await ReadNextContentLineAsync(reader);
        if (string.IsNullOrWhiteSpace(headerLine))
        {
            throw new InvalidOperationException($"{file.Name} does not contain any readable rows.");
        }

        var delimiter = DetectDelimiter(headerLine);
        var headers = ParseDelimitedLine(headerLine, delimiter);
        NormalizeHeaders(headers);

        var table = new TableModel
        {
            Name = Path.GetFileNameWithoutExtension(file.Name),
            OriginalFileName = file.Name,
            SourceType = Path.GetExtension(file.Name).Equals(".txt", StringComparison.OrdinalIgnoreCase) ? "Text file" : "CSV file",
            Delimiter = delimiter.ToString(),
            Columns = headers.Select(header => new ColumnModel { Name = header }).ToList()
        };

        string? line;
        while ((line = await reader.ReadLineAsync()) is not null)
        {
            if (string.IsNullOrWhiteSpace(line))
            {
                continue;
            }

            table.RowCount++;
            if (table.PreviewRows.Count >= MaxStoredRowsPerTable)
            {
                continue;
            }

            var values = ParseDelimitedLine(line, delimiter);
            table.PreviewRows.Add(MapValues(headers, values));
        }

        ApplyInferredColumnTypes(table);
        return table;
    }

    private async Task<TableModel> CreateTableFromXlsxAsync(IBrowserFile file)
    {
        await using var uploadStream = file.OpenReadStream(MaxUploadSize);
        using var memoryStream = new MemoryStream();
        await uploadStream.CopyToAsync(memoryStream);
        memoryStream.Position = 0;

        using var archive = new ZipArchive(memoryStream, ZipArchiveMode.Read, leaveOpen: false);
        var sheetEntry = ResolveFirstWorksheetEntry(archive)
            ?? throw new InvalidOperationException($"{file.Name} does not contain a readable worksheet.");

        var sharedStrings = ReadSharedStrings(archive);

        using var sheetStream = sheetEntry.Open();
        var document = XDocument.Load(sheetStream);
        XNamespace spreadsheetNs = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

        var rows = document
            .Descendants(spreadsheetNs + "sheetData")
            .Elements(spreadsheetNs + "row")
            .Select(row => ReadWorksheetRow(row, sharedStrings))
            .Where(row => row.Any(value => !string.IsNullOrWhiteSpace(value)))
            .ToList();

        if (rows.Count == 0)
        {
            throw new InvalidOperationException($"{file.Name} does not contain any readable rows.");
        }

        var headers = rows[0];
        NormalizeHeaders(headers);

        var table = new TableModel
        {
            Name = Path.GetFileNameWithoutExtension(file.Name),
            OriginalFileName = file.Name,
            SourceType = "Excel workbook",
            Delimiter = "worksheet",
            Columns = headers.Select(header => new ColumnModel { Name = header }).ToList()
        };

        foreach (var row in rows.Skip(1))
        {
            table.RowCount++;
            if (table.PreviewRows.Count >= MaxStoredRowsPerTable)
            {
                continue;
            }

            table.PreviewRows.Add(MapValues(headers, row));
        }

        ApplyInferredColumnTypes(table);
        return table;
    }

    private async Task WriteExtractAsync(DataSourceModel source)
    {
        Directory.CreateDirectory(_extractsPath);
        await using var stream = File.Create(GetExtractPath(source));
        await using var writer = new StreamWriter(stream, Encoding.UTF8);

        foreach (var table in source.Tables.Where(table => table.IsSelected))
        {
            var selectedColumns = table.Columns
                .Where(column => column.IsSelected)
                .Select(column => column.Name)
                .ToList();

            foreach (var row in table.PreviewRows)
            {
                var record = new Dictionary<string, object?>
                {
                    ["sourceId"] = source.Id,
                    ["sourceName"] = source.Name,
                    ["tableId"] = table.Id,
                    ["tableName"] = table.Name
                };

                foreach (var column in selectedColumns)
                {
                    record[column] = row.TryGetValue(column, out var value) ? value : string.Empty;
                }

                await writer.WriteLineAsync(JsonSerializer.Serialize(record, _jsonOptions));
            }
        }
    }

    private static async Task<string?> ReadNextContentLineAsync(StreamReader reader)
    {
        string? line;
        while ((line = await reader.ReadLineAsync()) is not null)
        {
            if (!string.IsNullOrWhiteSpace(line))
            {
                return line;
            }
        }

        return null;
    }

    private static char DetectDelimiter(string line)
    {
        var candidates = new[] { ',', '\t', ';', '|' };
        return candidates
            .Select(candidate => new { Delimiter = candidate, Count = line.Count(character => character == candidate) })
            .OrderByDescending(item => item.Count)
            .First().Delimiter;
    }

    private static List<string> ParseDelimitedLine(string line, char delimiter)
    {
        var values = new List<string>();
        var current = new StringBuilder();
        var inQuotes = false;

        for (var index = 0; index < line.Length; index++)
        {
            var character = line[index];
            if (character == '"')
            {
                if (inQuotes && index + 1 < line.Length && line[index + 1] == '"')
                {
                    current.Append('"');
                    index++;
                }
                else
                {
                    inQuotes = !inQuotes;
                }

                continue;
            }

            if (character == delimiter && !inQuotes)
            {
                values.Add(current.ToString().Trim());
                current.Clear();
                continue;
            }

            current.Append(character);
        }

        values.Add(current.ToString().Trim());
        return values;
    }

    private static List<string> SplitColumnText(string columnText)
    {
        return columnText
            .Split(new[] { ',', '\t', ';', '|', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(column => !string.IsNullOrWhiteSpace(column))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private static Dictionary<string, string> MapValues(IReadOnlyList<string> headers, IReadOnlyList<string> values)
    {
        var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        for (var index = 0; index < headers.Count; index++)
        {
            row[headers[index]] = index < values.Count ? values[index] : string.Empty;
        }

        return row;
    }

    private static void NormalizeHeaders(List<string> headers)
    {
        for (var index = 0; index < headers.Count; index++)
        {
            if (string.IsNullOrWhiteSpace(headers[index]))
            {
                headers[index] = $"Column{index + 1}";
            }

            var duplicateCount = headers.Take(index).Count(header => header.Equals(headers[index], StringComparison.OrdinalIgnoreCase));
            if (duplicateCount > 0)
            {
                headers[index] = $"{headers[index]} {duplicateCount + 1}";
            }
        }
    }

    private static void ApplyInferredColumnTypes(TableModel table)
    {
        foreach (var column in table.Columns)
        {
            var values = table.PreviewRows
                .Select(row => row.TryGetValue(column.Name, out var value) ? value : string.Empty)
                .Where(value => !string.IsNullOrWhiteSpace(value))
                .Take(50)
                .ToList();

            column.DataType = InferType(values);
            column.Role = column.DataType is "Number" ? "Measure" : "Dimension";
        }
    }

    private static string InferType(IReadOnlyList<string> values)
    {
        if (values.Count == 0)
        {
            return "Text";
        }

        if (values.All(value => decimal.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out _)))
        {
            return "Number";
        }

        if (values.All(value => DateTimeOffset.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out _)))
        {
            return "Date";
        }

        if (values.All(value => bool.TryParse(value, out _)))
        {
            return "Boolean";
        }

        return "Text";
    }

    private static ZipArchiveEntry? ResolveFirstWorksheetEntry(ZipArchive archive)
    {
        var workbookEntry = archive.GetEntry("xl/workbook.xml");
        var relationshipsEntry = archive.GetEntry("xl/_rels/workbook.xml.rels");

        if (workbookEntry is null || relationshipsEntry is null)
        {
            return archive.GetEntry("xl/worksheets/sheet1.xml");
        }

        using var workbookStream = workbookEntry.Open();
        using var relationshipsStream = relationshipsEntry.Open();
        var workbook = XDocument.Load(workbookStream);
        var relationships = XDocument.Load(relationshipsStream);

        XNamespace spreadsheetNs = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        XNamespace officeRelNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        XNamespace packageRelNs = "http://schemas.openxmlformats.org/package/2006/relationships";

        var firstSheet = workbook.Descendants(spreadsheetNs + "sheet").FirstOrDefault();
        var relationshipId = firstSheet?.Attribute(officeRelNs + "id")?.Value;
        if (string.IsNullOrWhiteSpace(relationshipId))
        {
            return archive.GetEntry("xl/worksheets/sheet1.xml");
        }

        var target = relationships
            .Descendants(packageRelNs + "Relationship")
            .FirstOrDefault(relationship => relationship.Attribute("Id")?.Value == relationshipId)
            ?.Attribute("Target")
            ?.Value;

        if (string.IsNullOrWhiteSpace(target))
        {
            return archive.GetEntry("xl/worksheets/sheet1.xml");
        }

        var entryPath = target.StartsWith("/", StringComparison.Ordinal)
            ? target.TrimStart('/')
            : $"xl/{target}";

        return archive.GetEntry(entryPath.Replace('\\', '/'));
    }

    private static List<string> ReadSharedStrings(ZipArchive archive)
    {
        var sharedStrings = new List<string>();
        var sharedStringsEntry = archive.GetEntry("xl/sharedStrings.xml");
        if (sharedStringsEntry is null)
        {
            return sharedStrings;
        }

        using var stream = sharedStringsEntry.Open();
        var document = XDocument.Load(stream);
        XNamespace spreadsheetNs = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

        foreach (var item in document.Descendants(spreadsheetNs + "si"))
        {
            sharedStrings.Add(string.Concat(item.Descendants(spreadsheetNs + "t").Select(text => text.Value)));
        }

        return sharedStrings;
    }

    private static List<string> ReadWorksheetRow(XElement row, IReadOnlyList<string> sharedStrings)
    {
        XNamespace spreadsheetNs = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        var values = new List<string>();

        foreach (var cell in row.Elements(spreadsheetNs + "c"))
        {
            var columnIndex = GetColumnIndex(cell.Attribute("r")?.Value);
            while (values.Count <= columnIndex)
            {
                values.Add(string.Empty);
            }

            values[columnIndex] = ReadCellValue(cell, sharedStrings);
        }

        return values;
    }

    private static int GetColumnIndex(string? cellReference)
    {
        if (string.IsNullOrWhiteSpace(cellReference))
        {
            return 0;
        }

        var columnLetters = new string(cellReference.TakeWhile(char.IsLetter).ToArray());
        var index = 0;

        foreach (var letter in columnLetters.ToUpperInvariant())
        {
            index *= 26;
            index += letter - 'A' + 1;
        }

        return Math.Max(index - 1, 0);
    }

    private static string ReadCellValue(XElement cell, IReadOnlyList<string> sharedStrings)
    {
        XNamespace spreadsheetNs = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        var rawValue = cell.Element(spreadsheetNs + "v")?.Value ?? cell.Element(spreadsheetNs + "is")?.Value ?? string.Empty;
        var type = cell.Attribute("t")?.Value;

        if (type == "s" && int.TryParse(rawValue, out var sharedStringIndex) && sharedStringIndex < sharedStrings.Count)
        {
            return sharedStrings[sharedStringIndex];
        }

        if (type == "inlineStr")
        {
            return string.Concat(cell.Descendants(spreadsheetNs + "t").Select(text => text.Value));
        }

        return rawValue;
    }

    private void EnsureStorage()
    {
        Directory.CreateDirectory(_rootPath);
        Directory.CreateDirectory(_dataSourcesPath);
        Directory.CreateDirectory(_dashboardsPath);
        Directory.CreateDirectory(_combinationsPath);
        Directory.CreateDirectory(_extractsPath);
    }

    private void SeedDemoWorkspace()
    {
        if (Directory.EnumerateFiles(_dataSourcesPath, "*.json").Any())
        {
            return;
        }

        var source = new DataSourceModel
        {
            Id = "demo-sales-source",
            Name = "Demo Sales Extract",
            IsPublished = true,
            LastRefreshedAt = DateTimeOffset.UtcNow.AddMinutes(-12),
            ExtractFileName = "demo-sales-extract.jsonl",
            Tables = new List<TableModel>
            {
                new()
                {
                    Id = "demo-orders",
                    Name = "Orders",
                    SourceType = "Seed data",
                    RowCount = 6,
                    Columns = new List<ColumnModel>
                    {
                        new() { Name = "Order Date", DataType = "Date" },
                        new() { Name = "Region", DataType = "Text" },
                        new() { Name = "Category", DataType = "Text" },
                        new() { Name = "Sales", DataType = "Number", Role = "Measure" },
                        new() { Name = "Profit", DataType = "Number", Role = "Measure" }
                    },
                    PreviewRows = new List<Dictionary<string, string>>
                    {
                        new() { ["Order Date"] = "2026-01-04", ["Region"] = "West", ["Category"] = "Technology", ["Sales"] = "12800", ["Profit"] = "2840" },
                        new() { ["Order Date"] = "2026-01-12", ["Region"] = "North", ["Category"] = "Furniture", ["Sales"] = "8400", ["Profit"] = "1210" },
                        new() { ["Order Date"] = "2026-02-02", ["Region"] = "South", ["Category"] = "Office", ["Sales"] = "5600", ["Profit"] = "870" },
                        new() { ["Order Date"] = "2026-02-20", ["Region"] = "East", ["Category"] = "Technology", ["Sales"] = "14200", ["Profit"] = "3330" },
                        new() { ["Order Date"] = "2026-03-05", ["Region"] = "West", ["Category"] = "Furniture", ["Sales"] = "9200", ["Profit"] = "1640" },
                        new() { ["Order Date"] = "2026-03-18", ["Region"] = "North", ["Category"] = "Office", ["Sales"] = "6200", ["Profit"] = "980" }
                    }
                },
                new()
                {
                    Id = "demo-targets",
                    Name = "Targets",
                    SourceType = "Seed data",
                    RowCount = 4,
                    Columns = new List<ColumnModel>
                    {
                        new() { Name = "Region", DataType = "Text" },
                        new() { Name = "Quarterly Target", DataType = "Number", Role = "Measure" }
                    },
                    PreviewRows = new List<Dictionary<string, string>>
                    {
                        new() { ["Region"] = "West", ["Quarterly Target"] = "24000" },
                        new() { ["Region"] = "North", ["Quarterly Target"] = "19000" },
                        new() { ["Region"] = "South", ["Quarterly Target"] = "15000" },
                        new() { ["Region"] = "East", ["Quarterly Target"] = "22000" }
                    }
                }
            },
            Joins = new List<DataJoinModel>
            {
                new()
                {
                    LeftTableId = "demo-orders",
                    LeftColumn = "Region",
                    RightTableId = "demo-targets",
                    RightColumn = "Region",
                    JoinType = "Left"
                }
            },
            RefreshHistory = new List<RefreshEventModel>
            {
                new() { RefreshedAt = DateTimeOffset.UtcNow.AddMinutes(-12), Message = "Seed extract created" }
            }
        };

        SaveDataSourceAsync(source).GetAwaiter().GetResult();

        var dashboard = new DashboardDefinition
        {
            Id = "demo-executive-sales",
            Name = "Executive Sales Overview",
            DataSourceId = source.Id,
            DataSourceName = source.Name,
            Widgets = new List<DashboardWidget>
            {
                CreateSeedWidget("KPI", "Total Sales", 1, 1, 3, 2, "#0f766e"),
                CreateSeedWidget("KPI", "Profit Margin", 4, 1, 3, 2, "#2563eb"),
                CreateSeedWidget("Bar chart", "Sales by Region", 1, 3, 6, 4, "#b45309"),
                CreateSeedWidget("Line chart", "Monthly Sales Trend", 7, 1, 6, 3, "#7c3aed"),
                CreateSeedWidget("Filter", "Region Filter", 7, 4, 3, 2, "#475569"),
                CreateSeedWidget("Pie chart", "Category Mix", 10, 4, 3, 3, "#be123c")
            }
        };

        SerializeXml(DashboardPath(dashboard.Id), dashboard);

        var combination = new CombinedDashboardDefinition
        {
            Id = "demo-executive-wall",
            Name = "Executive Wall",
            SlideShowEnabled = true,
            Slots = new List<CombinedDashboardSlot>
            {
                new() { DashboardId = dashboard.Id, DashboardName = dashboard.Name, Position = 1 },
                new() { DashboardId = dashboard.Id, DashboardName = dashboard.Name, Position = 2 },
                new() { DashboardId = dashboard.Id, DashboardName = dashboard.Name, Position = 3 },
                new() { DashboardId = dashboard.Id, DashboardName = dashboard.Name, Position = 4 }
            }
        };

        SerializeXml(CombinationPath(combination.Id), combination);
    }

    private static DashboardWidget CreateSeedWidget(string type, string title, int x, int y, int width, int height, string color)
    {
        return new DashboardWidget
        {
            Type = type,
            Title = title,
            X = x,
            Y = y,
            Width = width,
            Height = height,
            AccentColor = color,
            Settings = new List<WidgetSetting>
            {
                new() { Key = "Field", Value = title },
                new() { Key = "Aggregation", Value = "Sum" }
            }
        };
    }

    private string DataSourcePath(string id) => Path.Combine(_dataSourcesPath, $"{id}.json");

    private string DashboardPath(string id) => Path.Combine(_dashboardsPath, $"{id}.xml");

    private string CombinationPath(string id) => Path.Combine(_combinationsPath, $"{id}.xml");

    private static string Slugify(string value)
    {
        var builder = new StringBuilder();
        foreach (var character in value.ToLowerInvariant())
        {
            if (char.IsLetterOrDigit(character))
            {
                builder.Append(character);
            }
            else if (builder.Length > 0 && builder[^1] != '-')
            {
                builder.Append('-');
            }
        }

        return builder.ToString().Trim('-') switch
        {
            "" => "extract",
            var slug => slug
        };
    }

    private static void SerializeXml<T>(string path, T value)
    {
        using var stream = File.Create(path);
        var serializer = new XmlSerializer(typeof(T));
        serializer.Serialize(stream, value);
    }

    private static T? DeserializeXml<T>(string path)
    {
        try
        {
            using var stream = File.OpenRead(path);
            var serializer = new XmlSerializer(typeof(T));
            return serializer.Deserialize(stream) is T value ? value : default;
        }
        catch
        {
            return default;
        }
    }
}
