using System.ComponentModel;

namespace MyBlazorApp.Models;

public sealed class DataSourceModel
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Untitled data source";
    public string StorageFormat { get; set; } = "Amaze Extract JSON Lines";
    public string ExtractFileName { get; set; } = string.Empty;
    public bool IsPublished { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public DateTimeOffset? LastRefreshedAt { get; set; }
    public RefreshPolicy RefreshPolicy { get; set; } = new();
    public List<TableModel> Tables { get; set; } = new();
    public List<DataJoinModel> Joins { get; set; } = new();
    public List<DataFilterModel> Filters { get; set; } = new();
    public List<CalculatedColumnModel> CalculatedColumns { get; set; } = new();
    public List<RefreshEventModel> RefreshHistory { get; set; } = new();
}

public sealed class RefreshPolicy
{
    public bool RefreshOnOpen { get; set; } = true;
    public int IntervalMinutes { get; set; } = 30;
    public string Mode { get; set; } = "Extract";
}

public sealed class RefreshEventModel
{
    public DateTimeOffset RefreshedAt { get; set; } = DateTimeOffset.UtcNow;
    public string Status { get; set; } = "Completed";
    public string Message { get; set; } = string.Empty;
}

public sealed class TableModel
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Table";
    public string SourceType { get; set; } = "Manual";
    public string OriginalFileName { get; set; } = string.Empty;
    public string Delimiter { get; set; } = ",";
    public int RowCount { get; set; }
    public bool IsSelected { get; set; } = true;
    public List<ColumnModel> Columns { get; set; } = new();
    public List<Dictionary<string, string>> PreviewRows { get; set; } = new();
}

public sealed class ColumnModel
{
    public string Name { get; set; } = string.Empty;
    public string DataType { get; set; } = "Text";
    public bool IsSelected { get; set; } = true;
    public string Role { get; set; } = "Dimension";
}

public sealed class DataJoinModel
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string LeftTableId { get; set; } = string.Empty;
    public string LeftColumn { get; set; } = string.Empty;
    public string RightTableId { get; set; } = string.Empty;
    public string RightColumn { get; set; } = string.Empty;
    public string JoinType { get; set; } = "Inner";
}

public sealed class DataFilterModel
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string TableId { get; set; } = string.Empty;
    public string Column { get; set; } = string.Empty;
    public string Operator { get; set; } = "Contains";
    public string Value { get; set; } = string.Empty;
}

public sealed class CalculatedColumnModel
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string TableId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Expression { get; set; } = string.Empty;
}

[DisplayName("AmazeDashboard")]
public sealed class DashboardDefinition
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Untitled dashboard";
    public string DataSourceId { get; set; } = string.Empty;
    public string DataSourceName { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public bool RefreshOnOpen { get; set; } = true;
    public int RefreshIntervalMinutes { get; set; } = 30;
    public List<DashboardWidget> Widgets { get; set; } = new();
}

public sealed class DashboardWidget
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Type { get; set; } = "KPI";
    public string Title { get; set; } = "Metric";
    public int X { get; set; } = 1;
    public int Y { get; set; } = 1;
    public int Width { get; set; } = 3;
    public int Height { get; set; } = 2;
    public string AccentColor { get; set; } = "#0f766e";
    public List<WidgetSetting> Settings { get; set; } = new();
}

public sealed class WidgetSetting
{
    public string Key { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
}

public sealed class CombinedDashboardDefinition
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Executive wall";
    public string LayoutMode { get; set; } = "Four corners";
    public bool SlideShowEnabled { get; set; }
    public int SlideDurationSeconds { get; set; } = 20;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public List<CombinedDashboardSlot> Slots { get; set; } = new();
}

public sealed class CombinedDashboardSlot
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string DashboardId { get; set; } = string.Empty;
    public string DashboardName { get; set; } = string.Empty;
    public int Position { get; set; }
}
